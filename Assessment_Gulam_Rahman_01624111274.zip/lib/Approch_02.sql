--(We are creating new view with all cells different values and check the data tables)
--Select * from db_data 
--select * from ehr_data
--we are creating 
/*CREATE VIEW db_flat AS
SELECT 
  patient_name,
  provider_name,
  from_date_range,
  TRIM(BOTH '{}' FROM cpt_code) AS cpt_code
FROM (
  SELECT 
    patient_name,
    provider_name,
    from_date_range,
    UNNEST(STRING_TO_ARRAY(REPLACE(REPLACE(cpt_codes, '{', ''), '}', ''), ',')) AS cpt_code
  FROM db_data
) AS expanded;
*/
--select* from db_flat


SELECT
  patient_name,
  date_of_service::DATE AS date_of_service,
  provider_name
FROM ehr_data
WHERE NOT EXISTS (
  SELECT 1
  FROM db_data
  WHERE 
    ehr_data.patient_name = db_data.patient_name
    AND ehr_data.date_of_service::DATE = db_data.from_date_range::DATE
    AND ehr_data.provider_name = db_data.provider_name
);

--WE got 1352 rows here asloo.