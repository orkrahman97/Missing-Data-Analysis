--Step-01 (We are importing and check the data tables)
--Select * from db_data 
--select * from ehr_data

--Step-02 (we are using NOT EXIST to check the missing datas because it will be check each field separately)

SELECT
  TRIM(patient_name) AS patient_name,
  date_of_service::DATE AS date_of_service,
  TRIM(provider_name) AS provider_name
FROM ehr_data
WHERE NOT EXISTS (
  SELECT 1
  FROM db_data
  WHERE 
    TRIM(ehr_data.patient_name) = TRIM(db_data.patient_name)
    AND ehr_data.date_of_service::DATE = db_data.from_date_range::DATE
    AND TRIM(ehr_data.provider_name) = TRIM(db_data.provider_name)
);
--we got 1352 Rows