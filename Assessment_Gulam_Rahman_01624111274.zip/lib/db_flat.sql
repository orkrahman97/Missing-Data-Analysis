select* from db_flat

/*CREATE VIEW db_flat AS
SELECT 
  patient_name,
  provider_name,
  from_date_range,
  TRIM(BOTH '{}' FROM cpt_code) AS cpt_code
FROM (
  SELECT 
    patient_name,
    provider_name,
    from_date_range,
    UNNEST(STRING_TO_ARRAY(REPLACE(REPLACE(cpt_codes, '{', ''), '}', ''), ',')) AS cpt_code
  FROM db_data
) AS expanded;
*/

