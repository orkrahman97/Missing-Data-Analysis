
SELECT 
  'Found Patient' AS category1,
  COUNT(*) AS count
FROM ehr_data

UNION ALL

SELECT 
  'Missing Patient' AS category2,
  COUNT(*) AS count
FROM ehr_data e
WHERE NOT EXISTS (
  SELECT 1 
  FROM db_data d
  WHERE 
    TRIM(e.patient_name) = TRIM(d.patient_name)
    AND e.date_of_service = d.from_date_range
    AND TRIM(e.provider_name) = TRIM(d.provider_name)
);
