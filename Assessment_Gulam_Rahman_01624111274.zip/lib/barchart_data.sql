
SELECT 
  provider_name, COUNT(*) AS missing_count
FROM (
  SELECT * FROM ehr_data e
  WHERE NOT EXISTS (
    SELECT 1 FROM db_data d
    WHERE 
      TRIM(e.patient_name) = TRIM(d.patient_name)
      AND e.date_of_service = d.from_date_range
      AND TRIM(e.provider_name) = TRIM(d.provider_name)
  )
) sub
GROUP BY provider_name;